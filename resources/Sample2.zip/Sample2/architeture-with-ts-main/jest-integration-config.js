const config = require('./jest.config')
config.testMatch = ['**/*.test.ts']
module.exports = config
