export interface EmailValidator {
  isValid: (Email: string) => boolean
}
